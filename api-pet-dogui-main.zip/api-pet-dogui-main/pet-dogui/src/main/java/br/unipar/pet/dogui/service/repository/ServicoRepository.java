package br.unipar.pet.dogui.service.repository;

import br.unipar.pet.dogui.model.Servico;
import br.unipar.pet.dogui.utils.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class ServicoRepository {

    private static final String INSERT
            = "INSERT INTO Servico (Ds_Servico, Vlr_Servico, Status) VALUES(?, ?, ?);";
    private static final String UPDATE
            = "UPDATE Servico SET Ds_Servico= ?, Vlr_Servico=?, Status= ? " +
              "WHERE id= ? ;";
    private static final String DELETE
            = "UPDATE Servico SET Status= false WHERE id= ? ;";
    private static final String FIND_BY_ID
            = "SELECT * FROM Servico where id = ?;";
    private static final String FIND_ALL
            = "SELECT * FROM Servico";

    
    public Servico insert(Servico servico) throws SQLException {

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
                
        try {
            
            conn = new ConnectionFactory().getConnection();

            ps = conn.prepareStatement(INSERT, 
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, servico.getDescricao());
            ps.setDouble(2, servico.getValor());
            ps.setBoolean(3, servico.isStatus());
            ps.executeUpdate();
            
            rs = ps.getGeneratedKeys();
            
            rs.next();
            servico.setId(rs.getInt(1));

        } finally {
            if (rs != null)
                rs.close();
            if (ps != null)
                ps.close();
            if (conn != null)
                conn.close();
        }

        return servico;
        
    }
    
    public ArrayList<Servico> findAll() throws SQLException {

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Servico> listaResultado = new ArrayList<>();
                
        try {

            conn = new ConnectionFactory().getConnection();

            ps = conn.prepareStatement(FIND_ALL);
            rs = ps.executeQuery();
            
            while(rs.next()){
                
                Servico servico = new Servico();
                servico.setDescricao(rs.getString("Ds_Servico"));
                servico.setId(rs.getInt("id"));
                servico.setValor(rs.getDouble("Vlr_Servico"));
                servico.setStatus(rs.getBoolean("Status"));
                
                listaResultado.add(servico);
            }

        } finally {
            if (rs != null)
                rs.close();
            if (ps != null)
                ps.close();
            if (conn != null)
                conn.close();
        }
        
        return listaResultado;

    }
    
    public ArrayList<Servico> findWithParameters(String descricao) throws SQLException {

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Servico> listaResultado = new ArrayList<>();
                
        try {

            conn = new ConnectionFactory().getConnection();

            ps = conn.prepareStatement(FIND_ALL + 
                    " where Ds_Servico like '%"+descricao+"%'");
            System.out.println(ps.toString());
            rs = ps.executeQuery();
            
            while(rs.next()){
                
                Servico servico = new Servico();
                servico.setDescricao(rs.getString("Ds_Servico"));
                servico.setId(rs.getInt("id"));
                servico.setValor(rs.getDouble("Vlr_Servico"));
                servico.setStatus(rs.getBoolean("Status"));
                
                listaResultado.add(servico);
            }

        } finally {
            if (rs != null)
                rs.close();
            if (ps != null)
                ps.close();
            if (conn != null)
                conn.close();
        }
        
        return listaResultado;

    }
    
    public void delete(int id) throws SQLException {

        Connection conn = null;
        PreparedStatement ps = null;
                
        try {

            conn = new ConnectionFactory().getConnection();

            ps = conn.prepareStatement(DELETE);
            ps.setInt(1, id);
            ps.execute();

        } finally {
            if (ps != null)
                ps.close();
            if (conn != null)
                conn.close();
        }

    }
    
    public Servico update(Servico servico) throws SQLException {

        Connection conn = null;
        PreparedStatement ps = null;
                
        try {

            conn = new ConnectionFactory().getConnection();

            ps = conn.prepareStatement(UPDATE);
            ps.setString(1, servico.getDescricao());
            ps.setDouble(2, servico.getValor());
            ps.setBoolean(3, servico.isStatus());
            ps.setInt(4, servico.getId());
            ps.execute();

        } finally {
            if (ps != null)
                ps.close();
            if (conn != null)
                conn.close();
        }

        return servico;
        
    }
    
    public Servico findById(int id) throws SQLException {   

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Servico resultado = new Servico();
                
        try {

            conn = new ConnectionFactory().getConnection();

            ps = conn.prepareStatement(FIND_BY_ID);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            
            while(rs.next()){
                
                resultado.setDescricao(rs.getString("Ds_Servico"));
                resultado.setId(rs.getInt("id"));
                resultado.setStatus(rs.getBoolean("Status"));
                resultado.setValor(rs.getDouble("Vlr_Servico"));
                
            }

        } finally {
            if (rs != null)
                rs.close();
            if (ps != null)
                ps.close();
            if (conn != null)
                conn.close();
        }
        
        return resultado;

    }
    
}

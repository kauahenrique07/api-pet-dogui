package br.unipar.pet.dogui.service.repository;

import br.unipar.pet.dogui.model.Endereco;
import br.unipar.pet.dogui.model.Pessoa;
import br.unipar.pet.dogui.model.Servico;
import br.unipar.pet.dogui.utils.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class EnderecoRepository {

    private static final String INSERT
            = "INSERT INTO Endereco (nome, Ds_Bairro, Nr_Casa, Nr_Cep, Complemento, St_Ativo, Id_Pessoa) VALUES(?, ?, ?, ?, ?, ?, ?);";
    private static final String UPDATE
            = "UPDATE Endereco SET nome=?, Ds_Bairro=?, Nr_Casa=?, Nr_Cep=?, Complemento=?, St_Ativo=?, Id_Pessoa=?"
            + "WHERE id= ? ;";
    private static final String DELETE
            = "UPDATE Endereco SET St_Ativo=false WHERE id= ? ;";
    private static final String FIND_BY_ID
            = "SELECT * FROM Endereco where id = ?";
    private static final String FIND_ALL
            = "SELECT * FROM Endereco";

    public Endereco insert(Endereco endereco) throws SQLException {

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {

            conn = new ConnectionFactory().getConnection();

            ps = conn.prepareStatement(INSERT,
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, endereco.getNomeRua());
            ps.setString(2, endereco.getDsBairro());
            ps.setInt(3, endereco.getNrCasa());
            ps.setString(4, endereco.getNrCep());
            ps.setString(5, endereco.getComplemento());
            ps.setBoolean(6, endereco.isStAtivo());
            ps.setInt(7, endereco.getPessoa().getId());
            ps.executeUpdate();

            rs = ps.getGeneratedKeys();

            rs.next();
            endereco.setId(rs.getInt(1));

        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return endereco;

    }

    public ArrayList<Endereco> findAll() throws SQLException {

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Endereco> listaResultado = new ArrayList<>();

        try {

            conn = new ConnectionFactory().getConnection();

            ps = conn.prepareStatement(FIND_ALL);
            rs = ps.executeQuery();

            while (rs.next()) {

                Endereco endereco = new Endereco();
                endereco.setId(rs.getInt("id"));
                endereco.setNomeRua(rs.getString("nome"));
                endereco.setComplemento("Complemento");
                endereco.setDsBairro(rs.getString("Ds_Bairro"));
                endereco.setNrCasa(rs.getInt("Nr_Casa"));
                endereco.setNrCep(rs.getString("Nr_Cep"));
                endereco.setStAtivo(rs.getBoolean("St_Ativo"));
                
                int pessoa_id = rs.getInt("Id_Pessoa");
                Pessoa pessoa = new PessoaRepository().findById(pessoa_id);
                endereco.setPessoa(pessoa);

                listaResultado.add(endereco);
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return listaResultado;

    }

    public ArrayList<Endereco> findWithParameters(String descricao) throws SQLException {

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ArrayList<Endereco> listaResultado = new ArrayList<>();

        try {

            conn = new ConnectionFactory().getConnection();

            ps = conn.prepareStatement(FIND_ALL
                    + " where nome like '%" + descricao + "%'");
            System.out.println(ps.toString());
            rs = ps.executeQuery();

            while (rs.next()) {

                Endereco endereco = new Endereco();
                endereco.setId(rs.getInt("id"));
                endereco.setNomeRua(rs.getString("nome"));
                endereco.setComplemento("Complemento");
                endereco.setDsBairro(rs.getString("Ds_Bairro"));
                endereco.setNrCasa(rs.getInt("Nr_Casa"));
                endereco.setNrCep(rs.getString("Nr_Cep"));
                endereco.setStAtivo(rs.getBoolean("St_Ativo"));
                
                int pessoa_id = rs.getInt("Id_Pessoa");
                Pessoa pessoa = new PessoaRepository().findById(pessoa_id);
                endereco.setPessoa(pessoa);

                listaResultado.add(endereco);
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return listaResultado;

    }

    public void delete(int id) throws SQLException {

        Connection conn = null;
        PreparedStatement ps = null;

        try {

            conn = new ConnectionFactory().getConnection();

            ps = conn.prepareStatement(DELETE);
            ps.setInt(1, id);
            ps.execute();

        } finally {
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

    }

    public Endereco update(Endereco endereco) throws SQLException {

        Connection conn = null;
        PreparedStatement ps = null;

        try {

            conn = new ConnectionFactory().getConnection();

            ps = conn.prepareStatement(UPDATE);
            ps.setString(1, endereco.getNomeRua());
            ps.setString(2, endereco.getDsBairro());
            ps.setInt(3, endereco.getNrCasa());
            ps.setString(4, endereco.getNrCep());
            ps.setString(5, endereco.getComplemento());
            ps.setBoolean(6, endereco.isStAtivo());
            ps.setInt(7, endereco.getPessoa().getId());
            ps.setInt(8, endereco.getId());
            ps.execute();

        } finally {
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return endereco;

    }

    public Endereco findById(int id) throws SQLException {

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Endereco resultado = new Endereco();

        try {

            conn = new ConnectionFactory().getConnection();

            ps = conn.prepareStatement(FIND_BY_ID);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            while (rs.next()) {

                resultado.setId(rs.getInt("id"));
                resultado.setNomeRua(rs.getString("nome"));
                resultado.setComplemento("Complemento");
                resultado.setDsBairro(rs.getString("Ds_Bairro"));
                resultado.setNrCasa(rs.getInt("Nr_Casa"));
                resultado.setNrCep(rs.getString("Nr_Cep"));
                resultado.setStAtivo(rs.getBoolean("St_Ativo"));
                
                int pessoa_id = rs.getInt("Id_Pessoa");
                Pessoa pessoa = new PessoaRepository().findById(pessoa_id);
                resultado.setPessoa(pessoa);

            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        }

        return resultado;

    }

}

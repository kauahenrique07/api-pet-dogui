package br.unipar.pet.dogui.model.enums;

public enum GeneroEnum {
    MACHO, FEMEA
}
